/**
 * Task tools.
 *
 * Wraps src/lib/taskList.ts as MCP tools. The shared task list is the swarm's
 * coordination backbone — teammates claim tasks from it, mark them completed,
 * and unblock dependent tasks. claim_task uses a per-task file lock so
 * concurrent teammates race-safely grab the same task.
 */
import {
  claimTask,
  claimTaskWithBusyCheck,
  createTask,
  getTask,
  listTasks,
  resetTaskList,
  updateTask,
  type ClaimResult,
} from '../lib/taskList.js'
import { type ToolDef, jsonResult, textResult } from './types.js'

/** Render a ClaimResult as a concise, model-friendly text summary. */
function renderClaimResult(result: ClaimResult): string {
  switch (result.status) {
    case 'claimed':
      return `Claimed task #${result.task.id} "${result.task.subject}". Set it in_progress, do the work, then call task_update(status:"completed").`
    case 'already_claimed':
      return `Task #${result.task.id} is already owned by "${result.task.owner}". Pick another.`
    case 'already_resolved':
      return `Task #${result.task.id} is already completed. Pick another.`
    case 'blocked':
      return `Task #${result.task.id} is blocked by: ${result.blockedByTasks.map(t => `#${t.id} (${t.status})`).join(', ')}. Wait for those to complete or pick another.`
    case 'agent_busy':
      return `You already own an in_progress task: ${result.busyWithTasks.map(t => `#${t.id}`).join(', ')}. Finish or complete it before claiming another.`
    case 'task_not_found':
      return `Task not found. Call task_list to see available ids.`
    default:
      return `Unexpected claim result: ${JSON.stringify(result)}`
  }
}

export const taskTools: ToolDef[] = [
  {
    name: 'task_create',
    description:
      'Add a new task to the team shared task list. The lead creates tasks; teammates may also create tasks for follow-up work they discover.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string', description: 'Team name (== task list id).' },
        subject: { type: 'string', description: 'Short task title.' },
        description: { type: 'string', description: 'What needs to be done, with enough detail for a teammate to start.' },
        blocked_by: {
          type: 'array',
          items: { type: 'number' },
          description: 'Task ids that must be completed before this one can be claimed.',
        },
      },
      required: ['team_name', 'subject'],
    },
    async handler(args) {
      const task = await createTask(String(args.team_name), {
        subject: String(args.subject),
        description: args.description ? String(args.description) : undefined,
        blockedBy: Array.isArray(args.blocked_by)
          ? (args.blocked_by as number[]).map(n => Number(n))
          : [],
      })
      return jsonResult(task)
    },
  },
  {
    name: 'task_list',
    description:
      'List all tasks in the team shared task list, sorted by id. Teammates call this after completing each task to find the next available work. Prefer claiming the lowest-id unblocked pending task.',
    inputSchema: {
      type: 'object',
      properties: { team_name: { type: 'string' } },
      required: ['team_name'],
    },
    async handler(args) {
      const tasks = await listTasks(String(args.team_name))
      if (tasks.length === 0) {
        return textResult('Task list is empty. No work available.')
      }
      return jsonResult(tasks)
    },
  },
  {
    name: 'task_info',
    description: 'Read a single task by id.',
    inputSchema: {
      type: 'object',
      properties: { team_name: { type: 'string' }, task_id: { type: 'number' } },
      required: ['team_name', 'task_id'],
    },
    async handler(args) {
      const task = await getTask(String(args.team_name), Number(args.task_id))
      if (!task) return textResult(`Task #${args.task_id} not found.`, true)
      return jsonResult(task)
    },
  },
  {
    name: 'task_update',
    description:
      'Update a task: set status (pending/in_progress/completed) and/or owner. Use status:"in_progress" when you start, status:"completed" when done. The owner is usually set automatically by claim_task.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        task_id: { type: 'number' },
        status: { type: 'string', enum: ['pending', 'in_progress', 'completed'] },
        owner: { type: 'string', description: 'Agent name to assign ownership to.' },
      },
      required: ['team_name', 'task_id'],
    },
    async handler(args) {
      const patch: { status?: 'pending' | 'in_progress' | 'completed'; owner?: string } = {}
      if (args.status) patch.status = args.status as 'pending' | 'in_progress' | 'completed'
      if (args.owner) patch.owner = String(args.owner)
      const task = await updateTask(String(args.team_name), Number(args.task_id), patch)
      return jsonResult(task)
    },
  },
  {
    name: 'claim_task',
    description:
      'Atomically claim an unclaimed, unblocked task for yourself. Returns "claimed" on success; otherwise explains why (already_claimed, blocked, already_resolved). This is the concurrency primitive that prevents two teammates from grabbing the same task.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        task_id: { type: 'number' },
        agent_name: { type: 'string', description: 'Your agent name (becomes the task owner).' },
        check_busy: {
          type: 'boolean',
          description: 'If true, refuse when you already own an in_progress task (one task at a time). Default false.',
        },
      },
      required: ['team_name', 'task_id', 'agent_name'],
    },
    async handler(args) {
      const result = args.check_busy
        ? await claimTaskWithBusyCheck(
            String(args.team_name),
            Number(args.task_id),
            String(args.agent_name),
          )
        : await claimTask(
            String(args.team_name),
            Number(args.task_id),
            String(args.agent_name),
          )
      return textResult(renderClaimResult(result), result.status === 'claimed' ? false : true)
    },
  },
  {
    name: 'task_reset',
    description:
      'Clear all tasks in a list (preserves the id counter so ids never reuse). Used by the lead when restarting a swarm.',
    inputSchema: {
      type: 'object',
      properties: { team_name: { type: 'string' } },
      required: ['team_name'],
    },
    async handler(args) {
      await resetTaskList(String(args.team_name))
      return textResult(`Task list "${args.team_name}" reset.`)
    },
  },
]
