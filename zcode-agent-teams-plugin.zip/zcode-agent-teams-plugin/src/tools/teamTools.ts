/**
 * Team management tools.
 *
 * Wraps src/lib/teamFile.ts as MCP tools. The lead uses team_create /
 * team_delete to manage a swarm's lifecycle; teammates use team_info /
 * team_join / team_set_active to register themselves and discover peers.
 */
import { existsSync } from 'node:fs'
import {
  addTeamMember,
  createTeam,
  deleteTeam,
  formatAgentId,
  getTeamFilePath,
  readTeamFileAsync,
  setMemberActive,
  type TeamMember,
} from '../lib/teamFile.js'
import { resetTaskList, getTasksDir } from '../lib/taskList.js'
import { TEAM_LEAD_NAME } from '../lib/constants.js'
import { type ToolDef, jsonResult, textResult } from './types.js'

export const teamTools: ToolDef[] = [
  {
    name: 'team_create',
    description:
      'Create a new agent team and its shared task list. Teams have a 1:1 correspondence with task lists (Team = TaskList). Call once at swarm start. Returns the team file path and lead agent id.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: {
          type: 'string',
          description: 'Name for the new team (used as the task list id).',
        },
        description: { type: 'string', description: 'Team purpose/goal.' },
        lead_agent_type: {
          type: 'string',
          description: 'Role of the team lead (default "team-lead").',
        },
      },
      required: ['team_name'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const existing = await readTeamFileAsync(teamName)
      if (existing) {
        return textResult(
          `Team "${teamName}" already exists at ${getTeamFilePath(teamName)}. Use team_info to inspect it, or pick a different name.`,
          true,
        )
      }
      const { teamFilePath, leadAgentId } = await createTeam({
        teamName,
        description: args.description ? String(args.description) : undefined,
        leadAgentType: args.lead_agent_type ? String(args.lead_agent_type) : undefined,
      })
      // (Team = TaskList) — reset/prepare the matching task list.
      await resetTaskList(teamName)
      return jsonResult({
        team_name: teamName,
        team_file_path: teamFilePath,
        lead_agent_id: leadAgentId,
        task_list_id: teamName,
        message: `Team created. Spawn teammates with the Agent tool (subagent_type:"teammate"), then have them call team_join + claim_task.`,
      })
    },
  },
  {
    name: 'team_delete',
    description:
      'Delete a team and its task list. Call after the swarm completes its work. Fails if members are still registered.',
    inputSchema: {
      type: 'object',
      properties: { team_name: { type: 'string' } },
      required: ['team_name'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const teamFile = await readTeamFileAsync(teamName)
      if (!teamFile) return textResult(`Team "${teamName}" not found.`, true)
      const nonLead = teamFile.members.filter(m => m.name !== TEAM_LEAD_NAME)
      if (nonLead.length > 0) {
        return textResult(
          `Cannot delete team "${teamName}": ${nonLead.length} teammate(s) still registered (${nonLead.map(m => m.name).join(', ')}). Have them shut down first.`,
          true,
        )
      }
      const tasksDir = getTasksDir(teamName)
      await deleteTeam(teamName, existsSync(tasksDir) ? tasksDir : undefined)
      return textResult(`Team "${teamName}" and its task list deleted.`)
    },
  },
  {
    name: 'team_info',
    description:
      'Read a team config file to discover members (names, agent types, active status). Teammates call this to find peers they can message. Refer to members by NAME for mailbox_send and task ownership.',
    inputSchema: {
      type: 'object',
      properties: { team_name: { type: 'string' } },
      required: ['team_name'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const teamFile = await readTeamFileAsync(teamName)
      if (!teamFile) return textResult(`Team "${teamName}" not found.`, true)
      return jsonResult(teamFile)
    },
  },
  {
    name: 'team_join',
    description:
      'Register yourself as a member of a team. Called by a teammate right after it spawns, before claiming tasks. Records your agent id so the lead and peers can discover and message you.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        agent_name: { type: 'string', description: 'Your display name (e.g. "worker-A").' },
        agent_type: { type: 'string', description: 'Your role (default "teammate").' },
        task_id: {
          type: 'string',
          description: 'The ZCode subagent task id returned by the Agent tool, so the lead can steer you via SendMessage.',
        },
      },
      required: ['team_name', 'agent_name'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const agentName = String(args.agent_name)
      const agentId = formatAgentId(agentName, teamName)
      const member: TeamMember = {
        agentId,
        name: agentName,
        agentType: args.agent_type ? String(args.agent_type) : 'teammate',
        joinedAt: Date.now(),
        taskId: args.task_id ? String(args.task_id) : undefined,
        isActive: true,
        subscriptions: [],
      }
      const teamFile = await addTeamMember(teamName, member)
      return jsonResult({
        agent_id: agentId,
        team_name: teamName,
        members: teamFile.members.map(m => ({ name: m.name, agentType: m.agentType, isActive: m.isActive })),
        message: `Joined team "${teamName}" as "${agentName}". Read your mailbox, then call task_list + claim_task.`,
      })
    },
  },
  {
    name: 'team_set_active',
    description:
      'Update a member active/idle status. Teammates call this (isActive:false) when they finish their turn and go idle, so the lead knows whether to assign new work.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        agent_name: { type: 'string' },
        is_active: { type: 'boolean' },
      },
      required: ['team_name', 'agent_name', 'is_active'],
    },
    async handler(args) {
      await setMemberActive(
        String(args.team_name),
        String(args.agent_name),
        Boolean(args.is_active),
      )
      return textResult(
        `Member "${args.agent_name}" marked ${args.is_active ? 'active' : 'idle'}.`,
      )
    },
  },
]
