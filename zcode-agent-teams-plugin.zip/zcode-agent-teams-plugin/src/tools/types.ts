/**
 * Shared types for MCP tool definitions.
 *
 * We use the low-level MCP SDK pattern (ListToolsRequestSchema +
 * CallToolRequestSchema with a central dispatcher), matching the
 * zcode-computer-use-plugin's proven shape. Tool input schemas are plain
 * JSON Schema objects; each tool carries a `name`, `description`, `inputSchema`,
 * and a `handler` that returns a CallToolResult.
 */
import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js'

export type ToolHandler = (
  args: Record<string, unknown>,
) => Promise<CallToolResult>

export type ToolDef = {
  name: string
  description: string
  inputSchema: {
    type: 'object'
    properties: Record<string, unknown>
    required?: string[]
  }
  handler: ToolHandler
}

/** Build a text-only CallToolResult. */
export function textResult(text: string, isError = false): CallToolResult {
  return {
    content: [{ type: 'text', text }],
    isError,
  }
}

/** Build a JSON CallToolResult (pretty-printed). */
export function jsonResult(data: unknown, isError = false): CallToolResult {
  return {
    content: [{ type: 'text', text: JSON.stringify(data, null, 2) }],
    isError,
  }
}
