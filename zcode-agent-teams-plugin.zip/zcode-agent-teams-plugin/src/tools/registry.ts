/**
 * Tool registry — aggregates all swarm MCP tools and indexes them by name.
 *
 * These tools are only relevant to the /swarm workflow. /coordinator uses
 * ZCode's built-in Agent + SendMessage tools directly and needs no MCP tools.
 */
import { mailboxTools } from './mailboxTools.js'
import { taskTools } from './taskTools.js'
import { teamTools } from './teamTools.js'
import type { ToolDef } from './types.js'

export const ALL_TOOLS: ToolDef[] = [
  ...teamTools,
  ...mailboxTools,
  ...taskTools,
]

export const TOOLS_BY_NAME: Map<string, ToolDef> = new Map(
  ALL_TOOLS.map(t => [t.name, t]),
)
