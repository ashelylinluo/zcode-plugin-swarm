/**
 * Mailbox tools.
 *
 * Wraps src/lib/mailbox.ts as MCP tools. This is the swarm's inter-agent
 * communication primitive — it bypasses ZCode's star-shaped SendMessage
 * (which can only go lead→child) by giving every teammate a file-backed inbox
 * that any peer can write to.
 *
 * Inbox layout: ~/.zcode/teams/{team_name}/inboxes/{agent_name}.json
 */
import {
  clearMailbox,
  getInboxPath,
  markMessagesAsRead,
  readMailbox,
  readUnreadMessages,
  writeToMailbox,
} from '../lib/mailbox.js'
import { readTeamFileAsync } from '../lib/teamFile.js'
import { type ToolDef, jsonResult, textResult } from './types.js'

export const mailboxTools: ToolDef[] = [
  {
    name: 'mailbox_send',
    description:
      'Send a message to a specific teammate by name. The recipient reads it on their next mailbox_read call. Use this for direct coordination between peers (not just lead→worker).',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        to: { type: 'string', description: 'Recipient agent name (e.g. "worker-A" or "team-lead").' },
        from: { type: 'string', description: 'Your agent name.' },
        message: { type: 'string', description: 'Message body in plain text.' },
        summary: { type: 'string', description: 'Optional 5-10 word preview shown in the inbox.' },
      },
      required: ['team_name', 'to', 'from', 'message'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const to = String(args.to)
      await writeToMailbox(
        to,
        {
          text: String(args.message),
          from: String(args.from),
          summary: args.summary ? String(args.summary) : undefined,
          timestamp: new Date().toISOString(),
        },
        teamName,
      )
      return textResult(
        `Message delivered to ${to}'s inbox (${getInboxPath(to, teamName)}).`,
      )
    },
  },
  {
    name: 'mailbox_broadcast',
    description:
      'Broadcast a message to every teammate in a team (including the lead). Use sparingly for team-wide notices.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        from: { type: 'string' },
        message: { type: 'string' },
      },
      required: ['team_name', 'from', 'message'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const teamFile = await readTeamFileAsync(teamName)
      if (!teamFile) return textResult(`Team "${teamName}" not found.`, true)
      const from = String(args.from)
      const text = String(args.message)
      let delivered = 0
      for (const member of teamFile.members) {
        if (member.name === from) continue // don't send to self
        await writeToMailbox(
          member.name,
          { text, from, summary: `[broadcast] ${text.slice(0, 60)}`, timestamp: new Date().toISOString() },
          teamName,
        )
        delivered++
      }
      return textResult(`Broadcast delivered to ${delivered} teammate(s).`)
    },
  },
  {
    name: 'mailbox_read',
    description:
      'Read unread messages from your inbox. Call this at the start of your turn (after team_join) to pick up instructions or peer messages. Returns an empty array if there is nothing new.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        agent_name: { type: 'string', description: 'Your agent name.' },
        mark_read: {
          type: 'boolean',
          description: 'If true (default), mark the returned messages as read.',
        },
      },
      required: ['team_name', 'agent_name'],
    },
    async handler(args) {
      const teamName = String(args.team_name)
      const agentName = String(args.agent_name)
      const markRead = args.mark_read !== false
      const unread = await readUnreadMessages(agentName, teamName)
      if (markRead && unread.length > 0) {
        await markMessagesAsRead(agentName, teamName)
      }
      return jsonResult(unread)
    },
  },
  {
    name: 'mailbox_read_all',
    description: 'Read all messages (read + unread) from an inbox, for full history.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        agent_name: { type: 'string' },
      },
      required: ['team_name', 'agent_name'],
    },
    async handler(args) {
      const all = await readMailbox(String(args.agent_name), String(args.team_name))
      return jsonResult(all)
    },
  },
  {
    name: 'mailbox_clear',
    description: 'Delete all messages from an inbox. No-op if the inbox does not exist.',
    inputSchema: {
      type: 'object',
      properties: {
        team_name: { type: 'string' },
        agent_name: { type: 'string' },
      },
      required: ['team_name', 'agent_name'],
    },
    async handler(args) {
      await clearMailbox(String(args.agent_name), String(args.team_name))
      return textResult(`Inbox cleared for ${args.agent_name}.`)
    },
  },
]
