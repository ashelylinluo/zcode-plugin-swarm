/**
 * Shared constants for the agent-teams plugin.
 *
 * Ported + trimmed from Claude Code `src/utils/swarm/constants.ts`:
 *  - dropped tmux / iTerm2 / socket / pane-related constants (ZCode is an
 *    Electron app with no pane concept).
 *  - kept TEAM_LEAD_NAME and the ZCode-specific config-home resolution.
 */
import { homedir } from 'node:os'
import { join } from 'node:path'

/** Canonical name for the team lead member in every team file. */
export const TEAM_LEAD_NAME = 'team-lead'

/**
 * Resolve the ZCode config home.
 *
 * Claude Code uses CLAUDE_CONFIG_DIR (default ~/.claude). ZCode desktop
 * stores everything under ~/.zcode, so we mirror that layout here.
 * Allow override via ZCODE_CONFIG_DIR for testing.
 */
export function getZcodeConfigHome(): string {
  return process.env.ZCODE_CONFIG_DIR ?? join(homedir(), '.zcode')
}

/** Root for all teams: ~/.zcode/teams/{team-name}/... */
export function getTeamsDir(): string {
  return join(getZcodeConfigHome(), 'teams')
}

/** Root for all task lists: ~/.zcode/tasks/{taskListId}/... */
export function getTasksRootDir(): string {
  return join(getZcodeConfigHome(), 'tasks')
}

/** Default agent type used when a teammate does not specify one. */
export const DEFAULT_AGENT_TYPE = 'teammate'

/** Colors cycled through when assigning teammate colors (round-robin). */
export const AGENT_COLORS = [
  'red',
  'green',
  'yellow',
  'blue',
  'magenta',
  'cyan',
] as const
export type AgentColorName = (typeof AGENT_COLORS)[number]
