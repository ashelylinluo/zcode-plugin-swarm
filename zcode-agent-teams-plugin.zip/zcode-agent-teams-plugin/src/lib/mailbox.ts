/**
 * Teammate Mailbox - file-based messaging system for agent swarms.
 *
 * Ported from Claude Code `src/utils/teammateMailbox.ts` with adaptations:
 *  - Dropped React rendering (formatTeammateMessages) — not needed in an MCP
 *    server that returns tool results, not UI fragments.
 *  - Dropped `getTeamName()`/`getAgentName()` env/AsyncLocalStorage identity
 *    resolution. ZCode teammates are isolated subprocesses; identity is passed
 *    explicitly as MCP tool arguments, so every function here requires
 *    `teamName` (no env-var fallback).
 *  - `lockfile` is imported statically (bundled by esbuild) instead of via the
 *    original dynamic require.
 *
 * Inbox layout: ~/.zcode/teams/{team_name}/inboxes/{agent_name}.json
 * Each inbox is a JSON array of TeammateMessage. Writes are serialized with a
 * per-inbox file lock (proper-lockfile) so concurrent teammates can't corrupt
 * each other's messages.
 */
import { randomBytes } from 'node:crypto'
import { mkdir, readFile, rename, stat, unlink, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { lock, type LockOptions } from './lockfile.js'
import { getTeamsDir } from './constants.js'

// Retry with backoff so concurrent callers (multiple teammates writing to the
// same inbox) wait for the lock instead of failing immediately.
const LOCK_OPTIONS: LockOptions = {
  // proper-lockfile reads `retries` off the options object.
  ...({
    retries: { retries: 10, minTimeout: 5, maxTimeout: 100 },
  } as LockOptions),
}

export const MAX_MAILBOX_MESSAGES = 1_000
export const MAX_READ_MAILBOX_MESSAGES = 200
export const MAX_MAILBOX_MESSAGE_TEXT_BYTES = 64 * 1024
export const MAX_MAILBOX_RETAINED_BYTES = 2 * 1024 * 1024
export const MAX_MAILBOX_FILE_BYTES = 4 * 1024 * 1024

export type TeammateMessage = {
  from: string
  text: string
  timestamp: string
  read: boolean
  color?: string
  summary?: string
}

function sanitizePathComponent(input: string): string {
  // Defensive path component sanitization — mirrors Claude Code's tasks.ts.
  return input.replace(/[^a-zA-Z0-9_-]/g, '-').toLowerCase()
}

// ---------------------------------------------------------------------------
// Validation & size limits
// ---------------------------------------------------------------------------

function assertMailboxMessageSize(message: TeammateMessage): void {
  const textBytes = Buffer.byteLength(message.text, 'utf8')
  if (textBytes > MAX_MAILBOX_MESSAGE_TEXT_BYTES) {
    throw new Error(
      `Mailbox message text exceeds ${MAX_MAILBOX_MESSAGE_TEXT_BYTES} bytes`,
    )
  }
}

function toMailboxMessage(value: unknown): TeammateMessage {
  if (!value || typeof value !== 'object') {
    throw new Error('Invalid mailbox message: expected object')
  }
  const record = value as Record<string, unknown>
  if (
    typeof record.from !== 'string' ||
    typeof record.text !== 'string' ||
    typeof record.timestamp !== 'string' ||
    typeof record.read !== 'boolean'
  ) {
    throw new Error('Invalid mailbox message shape')
  }
  const message: TeammateMessage = {
    from: record.from,
    text: record.text,
    timestamp: record.timestamp,
    read: record.read,
    ...(typeof record.color === 'string' ? { color: record.color } : {}),
    ...(typeof record.summary === 'string' ? { summary: record.summary } : {}),
  }
  assertMailboxMessageSize(message)
  return message
}

function parseMailboxMessages(content: string): TeammateMessage[] {
  const parsed = JSON.parse(content)
  if (!Array.isArray(parsed)) {
    throw new Error('Invalid mailbox file: expected message array')
  }
  return parsed.map(toMailboxMessage)
}

function mailboxMessageStorageBytes(message: TeammateMessage): number {
  return Buffer.byteLength(JSON.stringify(message), 'utf8')
}

// ---------------------------------------------------------------------------
// Compaction (evict old read messages, keep recent unread)
// ---------------------------------------------------------------------------

export function compactMailboxMessages(
  messages: TeammateMessage[],
): TeammateMessage[] {
  const maxMessages = MAX_MAILBOX_MESSAGES
  const maxReadMessages = MAX_READ_MAILBOX_MESSAGES
  const maxRetainedBytes = MAX_MAILBOX_RETAINED_BYTES

  if (maxRetainedBytes <= 0 || maxMessages <= 0) return []

  const keepIndexes = new Set<number>()
  let retainedBytes = 0
  const tryKeep = (index: number): boolean => {
    if (keepIndexes.has(index)) return true
    const message = messages[index]
    if (!message) return false
    const bytes = mailboxMessageStorageBytes(message)
    if (bytes > maxRetainedBytes || retainedBytes + bytes > maxRetainedBytes) {
      return false
    }
    keepIndexes.add(index)
    retainedBytes += bytes
    return true
  }

  // Keep unread first (newest first), then read messages.
  let keptUnread = 0
  for (let i = messages.length - 1; i >= 0; i--) {
    const message = messages[i]
    if (message && !message.read) {
      if (keptUnread >= maxMessages) continue
      if (tryKeep(i)) keptUnread++
    }
  }
  let keptRead = 0
  for (let i = messages.length - 1; i >= 0; i--) {
    if (keptRead >= maxReadMessages) break
    const message = messages[i]
    if (message?.read) {
      if (tryKeep(i)) keptRead++
    }
  }

  return messages.filter((_message, index) => keepIndexes.has(index))
}

// ---------------------------------------------------------------------------
// Low-level IO
// ---------------------------------------------------------------------------

async function readMailboxFile(inboxPath: string): Promise<string> {
  const info = await stat(inboxPath)
  if (info.size > MAX_MAILBOX_FILE_BYTES) {
    throw new Error(`Mailbox file exceeds ${MAX_MAILBOX_FILE_BYTES} bytes: ${inboxPath}`)
  }
  return readFile(inboxPath, 'utf-8')
}

async function readMailboxForMutation(
  agentName: string,
  teamName: string,
): Promise<TeammateMessage[]> {
  const inboxPath = getInboxPath(agentName, teamName)
  return parseMailboxMessages(await readMailboxFile(inboxPath))
}

async function writeMailboxAtomic(
  inboxPath: string,
  content: string,
): Promise<void> {
  const bytes = Buffer.byteLength(content, 'utf8')
  if (bytes > MAX_MAILBOX_FILE_BYTES) {
    throw new Error(`Compacted mailbox still exceeds ${MAX_MAILBOX_FILE_BYTES} bytes`)
  }
  const tempPath = `${inboxPath}.${process.pid}.${randomBytes(8).toString('hex')}.tmp`
  try {
    await writeFile(tempPath, content, 'utf-8')
    await rename(tempPath, inboxPath)
  } catch (error) {
    await unlink(tempPath).catch(() => undefined)
    throw error
  }
}

async function writeCompactedMailbox(
  inboxPath: string,
  messages: TeammateMessage[],
): Promise<void> {
  const compacted = compactMailboxMessages(messages)
  await writeMailboxAtomic(inboxPath, JSON.stringify(compacted, null, 2))
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Path to a teammate's inbox.
 * Structure: ~/.zcode/teams/{team_name}/inboxes/{agent_name}.json
 */
export function getInboxPath(agentName: string, teamName: string): string {
  const safeTeam = sanitizePathComponent(teamName)
  const safeAgentName = sanitizePathComponent(agentName)
  const inboxDir = join(getTeamsDir(), safeTeam, 'inboxes')
  return join(inboxDir, `${safeAgentName}.json`)
}

async function ensureInboxDir(teamName: string): Promise<void> {
  const safeTeam = sanitizePathComponent(teamName)
  const inboxDir = join(getTeamsDir(), safeTeam, 'inboxes')
  await mkdir(inboxDir, { recursive: true })
}

/** Read all messages from a teammate's inbox. Returns [] if absent. */
export async function readMailbox(
  agentName: string,
  teamName: string,
): Promise<TeammateMessage[]> {
  const inboxPath = getInboxPath(agentName, teamName)
  try {
    return parseMailboxMessages(await readMailboxFile(inboxPath))
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return []
    throw error
  }
}

/** Read only unread messages from a teammate's inbox. */
export async function readUnreadMessages(
  agentName: string,
  teamName: string,
): Promise<TeammateMessage[]> {
  const messages = await readMailbox(agentName, teamName)
  return messages.filter(m => !m.read)
}

/**
 * Write a message to a teammate's inbox.
 * Uses a per-inbox file lock so concurrent writers are serialized.
 */
export async function writeToMailbox(
  recipientName: string,
  message: Omit<TeammateMessage, 'read'>,
  teamName: string,
): Promise<void> {
  await ensureInboxDir(teamName)

  const inboxPath = getInboxPath(recipientName, teamName)
  const lockFilePath = `${inboxPath}.lock`

  // proper-lockfile requires the target file to exist before locking.
  try {
    await writeFile(inboxPath, '[]', { encoding: 'utf-8', flag: 'wx' })
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
  }

  let release: (() => Promise<void>) | undefined
  try {
    release = await lock(inboxPath, { lockfilePath: lockFilePath, ...LOCK_OPTIONS })

    // Re-read after acquiring the lock to get the latest state.
    const messages = await readMailboxForMutation(recipientName, teamName)
    messages.push(toMailboxMessage({ ...message, read: false }))
    await writeCompactedMailbox(inboxPath, messages)
  } finally {
    if (release) await release()
  }
}

/** Mark all messages in a teammate's inbox as read. */
export async function markMessagesAsRead(
  agentName: string,
  teamName: string,
): Promise<void> {
  const inboxPath = getInboxPath(agentName, teamName)
  const lockFilePath = `${inboxPath}.lock`

  let release: (() => Promise<void>) | undefined
  try {
    release = await lock(inboxPath, { lockfilePath: lockFilePath, ...LOCK_OPTIONS })
    const messages = await readMailboxForMutation(agentName, teamName)
    if (messages.length === 0) return
    for (const m of messages) m.read = true
    await writeCompactedMailbox(inboxPath, messages)
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return
    throw error
  } finally {
    if (release) await release()
  }
}

/** Clear a teammate's inbox (delete all messages). No-op if absent. */
export async function clearMailbox(
  agentName: string,
  teamName: string,
): Promise<void> {
  const inboxPath = getInboxPath(agentName, teamName)
  try {
    await writeFile(inboxPath, '[]', { encoding: 'utf-8', flag: 'r+' })
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return
    throw error
  }
}
