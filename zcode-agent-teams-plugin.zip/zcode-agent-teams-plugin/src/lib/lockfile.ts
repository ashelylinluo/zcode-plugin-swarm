/**
 * Lockfile - lazy wrapper around `proper-lockfile`.
 *
 * Ported from Claude Code `src/utils/lockfile.ts`.
 * `proper-lockfile` pulls in `graceful-fs`, which monkey-patches all fs
 * methods on first require (~8ms). We defer the require until the first
 * real lock call so the MCP server's startup path stays cheap.
 *
 * tasks.ts / mailbox.ts only use `lock` (returns a release callback invoked
 * inside try/finally). `unlock` / `check` are exported for completeness.
 */
import type { LockOptions } from 'proper-lockfile'

type Lockfile = {
  lock: (
    file: string,
    options?: LockOptions,
  ) => Promise<() => Promise<void>>
  unlock: (file: string, options?: unknown) => Promise<void>
  check: (file: string, options?: unknown) => Promise<boolean>
}

let _lockfile: Lockfile | undefined

function getLockfile(): Lockfile {
  if (!_lockfile) {
    // proper-lockfile is CJS; bundler handles the interop.
    _lockfile = require('proper-lockfile') as Lockfile
  }
  return _lockfile
}

export function lock(
  file: string,
  options?: LockOptions,
): Promise<() => Promise<void>> {
  return getLockfile().lock(file, options)
}

export function unlock(file: string, options?: unknown): Promise<void> {
  return getLockfile().unlock(file, options)
}

export function check(file: string, options?: unknown): Promise<boolean> {
  return getLockfile().check(file, options)
}

export type { LockOptions }
