/**
 * Task list system for agent swarms.
 *
 * Ported from Claude Code `src/utils/tasks.ts`, trimmed for ZCode:
 *  - Dropped in-process event emission (notifyTasksUpdated / EventEmitter) —
 *    the MCP server is stateless across tool calls; the lead polls task_list
 *    instead of receiving push notifications.
 *  - Dropped env/AsyncLocalStorage taskListId resolution. ZCode teammates are
 *    isolated subprocesses; the task list id (== sanitized team name) is passed
 *    explicitly to every function.
 *  - Kept the core concurrency primitive: per-task file locking (proper-lockfile)
 *    so concurrent teammates race-safely claim the same task.
 *
 * Storage layout:
 *   ~/.zcode/tasks/{taskListId}/1.json   ← one JSON file per task
 *   ~/.zcode/tasks/{taskListId}/.lock    ← list-level lock (busy-check path)
 *   ~/.zcode/tasks/{taskListId}/.highwatermark  ← max ever-assigned id
 */
import { mkdir, readFile, readdir, unlink, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { lock, type LockOptions } from './lockfile.js'
import { getTasksRootDir } from './constants.js'

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

export const TASK_STATUSES = ['pending', 'in_progress', 'completed'] as const
export type TaskStatus = (typeof TASK_STATUSES)[number]

const LOCK_OPTIONS: LockOptions = {
  ...({ retries: { retries: 30, minTimeout: 5, maxTimeout: 100 } } as LockOptions),
}

const HIGH_WATER_MARK_FILE = '.highwatermark'
const LIST_LOCK_FILE = '.lock'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type Task = {
  id: number
  subject: string
  description?: string
  activeForm?: string
  owner?: string
  status: TaskStatus
  blocks: number[]
  blockedBy: number[]
  metadata?: Record<string, unknown>
}

export type ClaimResult =
  | { status: 'claimed'; task: Task }
  | { status: 'already_claimed'; task: Task }
  | { status: 'already_resolved'; task: Task }
  | { status: 'blocked'; task: Task; blockedByTasks: Task[] }
  | { status: 'task_not_found' }
  | { status: 'agent_busy'; busyWithTasks: Task[] }

// ---------------------------------------------------------------------------
// Path helpers
// ---------------------------------------------------------------------------

function sanitizePathComponent(input: string): string {
  return input.replace(/[^a-zA-Z0-9_-]/g, '-')
}

export function getTasksDir(taskListId: string): string {
  return join(getTasksRootDir(), sanitizePathComponent(taskListId))
}

export function getTaskPath(taskListId: string, taskId: number): string {
  return join(getTasksDir(taskListId), `${taskId}.json`)
}

function getListLockPath(taskListId: string): string {
  return join(getTasksDir(taskListId), LIST_LOCK_FILE)
}

function getHighWaterMarkPath(taskListId: string): string {
  return join(getTasksDir(taskListId), HIGH_WATER_MARK_FILE)
}

export async function ensureTasksDir(taskListId: string): Promise<void> {
  await mkdir(getTasksDir(taskListId), { recursive: true })
}

// ---------------------------------------------------------------------------
// Read / write
// ---------------------------------------------------------------------------

async function readTaskFile(path: string): Promise<Task | null> {
  try {
    const content = await readFile(path, 'utf-8')
    return JSON.parse(content) as Task
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw e
  }
}

export async function getTask(
  taskListId: string,
  taskId: number,
): Promise<Task | null> {
  return readTaskFile(getTaskPath(taskListId, taskId))
}

export async function listTasks(taskListId: string): Promise<Task[]> {
  const dir = getTasksDir(taskListId)
  if (!existsSync(dir)) return []
  const entries = await readdir(dir)
  const tasks: Task[] = []
  for (const entry of entries) {
    if (!entry.endsWith('.json')) continue
    const task = await readTaskFile(join(dir, entry))
    if (task) tasks.push(task)
  }
  // Sort by id ascending — earlier tasks often set up context for later ones.
  tasks.sort((a, b) => a.id - b.id)
  return tasks
}

/** Internal: write a task without locking. Caller must already hold the lock. */
async function updateTaskUnsafe(
  taskListId: string,
  taskId: number,
  patch: Partial<Task>,
): Promise<Task> {
  const path = getTaskPath(taskListId, taskId)
  const task = await readTaskFile(path)
  if (!task) throw new Error(`Task ${taskId} not found in list ${taskListId}`)
  const updated: Task = { ...task, ...patch }
  await writeFile(path, JSON.stringify(updated, null, 2), 'utf-8')
  return updated
}

/** Public update — acquires a per-task file lock. */
export async function updateTask(
  taskListId: string,
  taskId: number,
  patch: Partial<Task>,
): Promise<Task> {
  const path = getTaskPath(taskListId, taskId)
  // Fast path: avoid acquiring the lock when the file is clearly absent.
  if (!existsSync(path)) {
    throw new Error(`Task ${taskId} not found in list ${taskListId}`)
  }
  // TOCTOU guard: between the existsSync above and lock() below, resetTaskList
  // (which holds the list lock, not this per-task lock) may delete the file.
  // proper-lockfile throws ENOENT when its target vanishes, so catch that and
  // surface it as a normal "not found" rather than letting it reject.
  let release: () => Promise<void>
  try {
    release = await lock(path, LOCK_OPTIONS)
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`Task ${taskId} not found in list ${taskListId}`)
    }
    throw e
  }
  try {
    return await updateTaskUnsafe(taskListId, taskId, patch)
  } finally {
    await release()
  }
}

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

/** Allocate the next task id via the high-water-mark file (locked). */
async function nextTaskId(taskListId: string): Promise<number> {
  await ensureTasksDir(taskListId)
  const lockPath = getListLockPath(taskListId)
  // Touch the list lock file so proper-lockfile can lock it.
  if (!existsSync(lockPath)) {
    await writeFile(lockPath, '', 'utf-8').catch(() => undefined)
  }
  const hwmPath = getHighWaterMarkPath(taskListId)
  const release = await lock(lockPath, LOCK_OPTIONS)
  try {
    let hwm = 0
    try {
      hwm = parseInt(await readFile(hwmPath, 'utf-8'), 10) || 0
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e
    }
    const nextId = hwm + 1
    await writeFile(hwmPath, String(nextId), 'utf-8')
    return nextId
  } finally {
    await release()
  }
}

export async function createTask(
  taskListId: string,
  args: {
    subject: string
    description?: string
    blockedBy?: number[]
  },
): Promise<Task> {
  const id = await nextTaskId(taskListId)
  const task: Task = {
    id,
    subject: args.subject,
    description: args.description,
    status: 'pending',
    blocks: [],
    blockedBy: args.blockedBy ?? [],
  }
  await ensureTasksDir(taskListId)
  await writeFile(getTaskPath(taskListId, id), JSON.stringify(task, null, 2), 'utf-8')

  // Backfill the `blocks` reverse-dependency on each blocker.
  for (const blockerId of task.blockedBy) {
    const blocker = await readTaskFile(getTaskPath(taskListId, blockerId))
    if (blocker && !blocker.blocks.includes(id)) {
      blocker.blocks.push(id)
      await writeFile(
        getTaskPath(taskListId, blockerId),
        JSON.stringify(blocker, null, 2),
        'utf-8',
      )
    }
  }
  return task
}

// ---------------------------------------------------------------------------
// Claim (core concurrency primitive)
// ---------------------------------------------------------------------------

/**
 * Atomically claim a task for an agent.
 *
 * Locks the single task file, re-checks status under the lock, and sets
 * `owner`. Returns the outcome without throwing on contention.
 */
export async function claimTask(
  taskListId: string,
  taskId: number,
  claimantAgentName: string,
): Promise<ClaimResult> {
  const path = getTaskPath(taskListId, taskId)
  // Fast path: skip locking when the file is clearly absent.
  if (!existsSync(path)) return { status: 'task_not_found' }

  // TOCTOU guard: resetTaskList (holding the list lock, not this per-task
  // lock) may delete the file between existsSync above and lock() below.
  // proper-lockfile throws ENOENT on a missing target; treat that as the task
  // being gone rather than letting the rejection escape.
  let release: () => Promise<void>
  try {
    release = await lock(path, LOCK_OPTIONS)
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
      return { status: 'task_not_found' }
    }
    throw e
  }
  try {
    const task = await readTaskFile(path)
    if (!task) return { status: 'task_not_found' }

    if (task.owner && task.owner !== claimantAgentName) {
      return { status: 'already_claimed', task }
    }
    if (task.status === 'completed') {
      return { status: 'already_resolved', task }
    }

    // Resolve blockers: a task is blocked if any blockedBy task isn't completed.
    const blockedByTasks: Task[] = []
    for (const blockerId of task.blockedBy) {
      const blocker = await readTaskFile(getTaskPath(taskListId, blockerId))
      if (blocker && blocker.status !== 'completed') {
        blockedByTasks.push(blocker)
      }
    }
    if (blockedByTasks.length > 0) {
      return { status: 'blocked', task, blockedByTasks }
    }

    // All clear — claim it. Unsafe variant: we already hold the lock.
    await updateTaskUnsafe(taskListId, taskId, { owner: claimantAgentName })
    const claimed = (await readTaskFile(path))!
    return { status: 'claimed', task: claimed }
  } finally {
    await release()
  }
}

/**
 * Claim with an agent-busy check (list-level lock).
 *
 * Refuses to assign a task if the claimant already owns another in-progress
 * task in the same list. This mirrors Claude Code's claimTaskWithBusyCheck for
 * the single-process-per-task model ZCode uses.
 */
export async function claimTaskWithBusyCheck(
  taskListId: string,
  taskId: number,
  claimantAgentName: string,
): Promise<ClaimResult> {
  await ensureTasksDir(taskListId)
  const lockPath = getListLockPath(taskListId)
  if (!existsSync(lockPath)) {
    await writeFile(lockPath, '', 'utf-8').catch(() => undefined)
  }
  const release = await lock(lockPath, LOCK_OPTIONS)
  try {
    const allTasks = await listTasks(taskListId)

    // Agent-busy check: does this agent already own an in_progress task?
    const busyWithTasks = allTasks.filter(
      t => t.owner === claimantAgentName && t.status === 'in_progress',
    )
    if (busyWithTasks.length > 0) {
      return { status: 'agent_busy', busyWithTasks }
    }

    const task = allTasks.find(t => t.id === taskId)
    if (!task) return { status: 'task_not_found' }

    if (task.owner && task.owner !== claimantAgentName) {
      return { status: 'already_claimed', task }
    }
    if (task.status === 'completed') {
      return { status: 'already_resolved', task }
    }
    const blockedByTasks = task.blockedBy
      .map(id => allTasks.find(t => t.id === id))
      .filter((t): t is Task => !!t && t.status !== 'completed')
    if (blockedByTasks.length > 0) {
      return { status: 'blocked', task, blockedByTasks }
    }

    // updateTask re-acquires the per-task lock; that's a different lock from
    // the list lock we hold, so no deadlock.
    return { status: 'claimed', task: await updateTask(taskListId, taskId, { owner: claimantAgentName }) }
  } finally {
    await release()
  }
}

// ---------------------------------------------------------------------------
// Reset (new swarm)
// ---------------------------------------------------------------------------

/**
 * Reset a task list for a new swarm: clear all task files, preserving the
 * high-water-mark so task ids never reuse across resets.
 */
export async function resetTaskList(taskListId: string): Promise<void> {
  await ensureTasksDir(taskListId)
  const lockPath = getListLockPath(taskListId)
  if (!existsSync(lockPath)) {
    await writeFile(lockPath, '', 'utf-8').catch(() => undefined)
  }
  const hwmPath = getHighWaterMarkPath(taskListId)
  const release = await lock(lockPath, LOCK_OPTIONS)
  try {
    // Bump high-water-mark past any existing ids.
    const dir = getTasksDir(taskListId)
    const entries = await readdir(dir)
    let maxId = 0
    for (const entry of entries) {
      const m = entry.match(/^(\d+)\.json$/)
      if (m) maxId = Math.max(maxId, parseInt(m[1], 10))
    }
    let hwm = 0
    try {
      hwm = parseInt(await readFile(hwmPath, 'utf-8'), 10) || 0
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e
    }
    if (maxId > hwm) await writeFile(hwmPath, String(maxId), 'utf-8')

    // Delete existing task json files (keep .lock and .highwatermark).
    for (const entry of entries) {
      if (entry.endsWith('.json')) {
        await unlink(join(dir, entry)).catch(() => undefined)
      }
    }
  } finally {
    await release()
  }
}
