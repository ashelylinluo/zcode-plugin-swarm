/**
 * Team file CRUD.
 *
 * Ported from Claude Code `src/utils/swarm/teamHelpers.ts`, trimmed for ZCode:
 *  - Dropped git worktree management (destroyWorktree) — ZCode teammates share
 *    the working directory; no worktree isolation.
 *  - Dropped pane management (killOrphanedTeammatePanes, addHiddenPaneId) —
 *    ZCode is an Electron app with no pane concept.
 *  - Dropped Perfetto tracing and analytics (logEvent).
 *  - Simplified TeamFile member shape: replaced tmuxPaneId/backendType with an
 *    agentId that maps to ZCode's subagent task id (returned by the Agent tool).
 *
 * Team file: ~/.zcode/teams/{team-name}/config.json
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { getTeamsDir, TEAM_LEAD_NAME } from './constants.js'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type TeamMember = {
  /** Stable id "name@team-name" used for mailbox addressing. */
  agentId: string
  /** Human-readable name — always use this for messaging/task ownership. */
  name: string
  agentType?: string
  model?: string
  prompt?: string
  color?: string
  joinedAt: number
  /** ZCode subagent task id (returned by Agent tool), for SendMessage steering. */
  taskId?: string
  isActive?: boolean
  subscriptions: string[]
}

export type TeamFile = {
  name: string
  description?: string
  createdAt: number
  leadAgentId: string
  members: TeamMember[]
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Sanitize a name for use in directory / file paths. */
export function sanitizeName(name: string): string {
  return name.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()
}

/** Sanitize an agent name for use in deterministic agent IDs. */
export function sanitizeAgentName(name: string): string {
  return name.replace(/@/g, '-')
}

/** Build the canonical agent id: "name@team-name". */
export function formatAgentId(name: string, teamName: string): string {
  return `${sanitizeAgentName(name)}@${sanitizeName(teamName)}`
}

/** Parse "name@team-name" back into its parts. */
export function parseAgentId(agentId: string): { agentName: string; teamName: string } | null {
  const idx = agentId.lastIndexOf('@')
  if (idx <= 0) return null
  return { agentName: agentId.slice(0, idx), teamName: agentId.slice(idx + 1) }
}

export function getTeamDir(teamName: string): string {
  return join(getTeamsDir(), sanitizeName(teamName))
}

export function getTeamFilePath(teamName: string): string {
  return join(getTeamDir(teamName), 'config.json')
}

// ---------------------------------------------------------------------------
// Read / write
// ---------------------------------------------------------------------------

/** Read a team file (sync — for callers in synchronous paths). */
export function readTeamFile(teamName: string): TeamFile | null {
  try {
    const content = readFileSync(getTeamFilePath(teamName), 'utf-8')
    return JSON.parse(content) as TeamFile
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw e
  }
}

/** Read a team file (async — for tool handlers). */
export async function readTeamFileAsync(
  teamName: string,
): Promise<TeamFile | null> {
  try {
    const content = await readFile(getTeamFilePath(teamName), 'utf-8')
    return JSON.parse(content) as TeamFile
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw e
  }
}

function writeTeamFile(teamName: string, teamFile: TeamFile): void {
  const teamDir = getTeamDir(teamName)
  mkdirSync(teamDir, { recursive: true })
  writeFileSync(getTeamFilePath(teamName), JSON.stringify(teamFile, null, 2))
}

export async function writeTeamFileAsync(
  teamName: string,
  teamFile: TeamFile,
): Promise<void> {
  const teamDir = getTeamDir(teamName)
  await mkdir(teamDir, { recursive: true })
  await writeFile(getTeamFilePath(teamName), JSON.stringify(teamFile, null, 2))
}

// ---------------------------------------------------------------------------
// Member mutations
// ---------------------------------------------------------------------------

/** Add a member to a team. Creates the team file if absent (with this member). */
export async function addTeamMember(
  teamName: string,
  member: TeamMember,
): Promise<TeamFile> {
  const teamFile = (await readTeamFileAsync(teamName)) ?? {
    name: teamName,
    createdAt: Date.now(),
    leadAgentId: member.agentId,
    members: [],
  }
  // De-dupe by agentId; update if present.
  const existingIdx = teamFile.members.findIndex(m => m.agentId === member.agentId)
  if (existingIdx >= 0) {
    teamFile.members[existingIdx] = { ...teamFile.members[existingIdx], ...member }
  } else {
    teamFile.members.push(member)
  }
  await writeTeamFileAsync(teamName, teamFile)
  return teamFile
}

/** Remove a member by agentId. Returns true if removed. */
export async function removeMemberByAgentId(
  teamName: string,
  agentId: string,
): Promise<boolean> {
  const teamFile = await readTeamFileAsync(teamName)
  if (!teamFile) return false
  const before = teamFile.members.length
  teamFile.members = teamFile.members.filter(m => m.agentId !== agentId)
  if (teamFile.members.length === before) return false
  await writeTeamFileAsync(teamName, teamFile)
  return true
}

/** Update a member's active status (idle/active). */
export async function setMemberActive(
  teamName: string,
  memberName: string,
  isActive: boolean,
): Promise<void> {
  const teamFile = await readTeamFileAsync(teamName)
  if (!teamFile) return
  const member = teamFile.members.find(m => m.name === memberName)
  if (!member || member.isActive === isActive) return
  member.isActive = isActive
  await writeTeamFileAsync(teamName, teamFile)
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

/**
 * Create a brand-new team with a lead member.
 * Throws if the team already exists — callers should check first or generate a
 * unique name.
 */
export async function createTeam(args: {
  teamName: string
  description?: string
  leadAgentType?: string
  leadModel?: string
}): Promise<{ teamFile: TeamFile; teamFilePath: string; leadAgentId: string }> {
  const { teamName, description, leadAgentType, leadModel } = args
  const leadAgentId = formatAgentId(TEAM_LEAD_NAME, teamName)
  const teamFilePath = getTeamFilePath(teamName)

  const teamFile: TeamFile = {
    name: teamName,
    description,
    createdAt: Date.now(),
    leadAgentId,
    members: [
      {
        agentId: leadAgentId,
        name: TEAM_LEAD_NAME,
        agentType: leadAgentType ?? TEAM_LEAD_NAME,
        model: leadModel,
        joinedAt: Date.now(),
        subscriptions: [],
      },
    ],
  }
  await writeTeamFileAsync(teamName, teamFile)
  return { teamFile, teamFilePath, leadAgentId }
}

/** Remove the team directory and (optionally) its task list. */
export async function deleteTeam(
  teamName: string,
  tasksDir?: string,
): Promise<void> {
  const teamDir = getTeamDir(teamName)
  await rm(teamDir, { recursive: true, force: true })
  if (tasksDir) {
    await rm(tasksDir, { recursive: true, force: true }).catch(() => undefined)
  }
}
