/**
 * ZCode Agent Teams MCP Server.
 *
 * Spawned by ZCode via __zcode-plugin-host (see .zcode-plugin/plugin.json).
 * Exposes the swarm coordination tools (team / mailbox / task) over stdio.
 *
 * /coordinator does not use this server — it orchestrates purely through
 * ZCode's built-in Agent + SendMessage tools.
 */
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js'
import { ALL_TOOLS, TOOLS_BY_NAME } from './tools/registry.js'
import { textResult } from './tools/types.js'

const SERVER_NAME = 'zcode-agent-teams'
const SERVER_VERSION = '0.1.0'

function createServer(): Server {
  const server = new Server(
    { name: SERVER_NAME, version: SERVER_VERSION },
    { capabilities: { tools: {} } },
  )

  // ListTools: advertise every tool's name/description/inputSchema.
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: ALL_TOOLS.map(t => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
    })),
  }))

  // CallTool: dispatch to the matching handler, catch errors as tool results.
  server.setRequestHandler(CallToolRequestSchema, async request => {
    const { name, arguments: args } = request.params
    const tool = TOOLS_BY_NAME.get(name)
    if (!tool) {
      return textResult(`Unknown tool: ${name}`, true)
    }
    try {
      return await tool.handler((args ?? {}) as Record<string, unknown>)
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error)
      return textResult(`Tool "${name}" failed: ${msg}`, true)
    }
  })

  return server
}

export async function main(): Promise<void> {
  const server = createServer()
  const transport = new StdioServerTransport()
  await server.connect(transport)

  // Keep the process alive on stdin until the transport closes
  // (stdin EOF / error), otherwise __zcode-plugin-host would exit on return.
  await new Promise<void>(resolve => {
    transport.onclose = () => resolve()
    transport.onerror = () => resolve()
  })
}

// Entry point when run directly by __zcode-plugin-host.
main().catch(error => {
  console.error('[zcode-agent-teams] fatal:', error)
  process.exit(1)
})
