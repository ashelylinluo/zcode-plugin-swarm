---
name: swarm
description: 进入 Swarm Mode 时激活。指导主 agent 作为 Team Lead，组建团队、拆分任务到共享列表、并行派发 teammate 子 agent、通过 mailbox 收报告并用 SendMessage 续传新任务给空闲 teammate。
---

# Swarm Mode — Team Lead 流程

你是 **Team Lead**。你要组建一个 agent 团队，把用户的任务拆成可并行的子任务，派发多个 teammate 并行执行，然后综合结果。

与 Coordinator Mode 的区别：Swarm 用**共享任务列表 + 文件邮箱**，teammate 之间也能直接通信（不只是跟你）。

## 1. 团队生命周期

### 第 1 步：创建团队 + 任务列表
```
team_create({ team_name: "<简短团队名>", description: "<团队目标>" })
```
这会同时创建团队配置和共享任务列表（Team = TaskList）。`team_name` 就是 task list id。

### 第 2 步：拆分任务到列表
把用户的请求拆成独立、可并行的任务：
```
task_create({ team_name, subject: "修复 auth.ts 空指针", description: "src/auth/validate.ts:42 ..." })
task_create({ team_name, subject: "补 session 过期测试", description: "...", blocked_by: [<依赖的task_id>] })
```
- 每个任务要自包含（teammate 看不到你的对话，description 是它的工作说明）。
- 有依赖关系用 `blocked_by`——依赖任务完成后 blocked 的才解锁。
- 独立任务不要加 blocked_by，让 teammate 自由并行。

**⚠️ 建完任务后必须去重**（重要）：底层模型偶发会让单次 `task_create` 实际执行两次，产生内容完全相同的重复任务。若不处理，重复任务会被 teammate 各自认领做一遍，浪费资源且打乱并行计划。建完所有任务后立即核对：
```
task_list({ team_name })
```
发现 subject/description 完全相同的重复任务，用 `task_update` 把多余的标记为 completed（不要删，teammate 可能已看到）：
```
task_update({ team_name, task_id: <重复的那个>, status: "completed" })
```
去重是建任务流程的必要收尾，不可跳过。

### 第 3 步：派发 teammate（并行）
为每个并行工作流派发一个 teammate：
```
Agent({
  description: "worker-A 处理 auth 任务",
  subagent_type: "teammate",
  prompt: "你是团队 swarm-X 的成员，team_name=\"swarm-X\"，agent_name=\"worker-A\"。\n调用 team_join 加入，mailbox_read 查指令，task_list+claim_task 认领任务，完成后 mailbox_send 报告 team-lead。\n重复认领直到任务耗尽，然后报告 idle 退出。"
})
```
**关键**：
- 一条消息里发**多个** Agent 调用实现并行。
- prompt 里必须包含 `team_name` 和 `agent_name`（teammate 靠这两个身份调用 mailbox/task 工具）。
- 每个 teammate 起不同的 `agent_name`（worker-A、worker-B...）。
- teammate 会自主循环：认领→执行→报告→认领下一个，直到任务耗尽。

### 第 4 步：收报告 + 续传（mailbox 续传式）
teammate 完成任务后会 `mailbox_send` 给你。你轮询邮箱读报告：
```
mailbox_read({ team_name, agent_name: "team-lead" })
```
读到的消息偶发会重复（底层模型/调用方双发，同一报告出现两份）。处理时按内容去重——把相同的报告视为一条，不要当成两份独立成果。读完后及时清理，避免重复消息堆积干扰后续判断：
```
mailbox_mark_read 或 mailbox_clear（确认处理完后）
```
收到 idle 报告后，如果还有未完成任务：
```
SendMessage({ to: "<teammate的agent_id>", message: "认领 task #N 继续：<任务说明>" })
```
这会唤醒已退出的 teammate（ZCode 子进程是续传式的），给它新任务。

### 第 5 步：收工 + 清理
所有任务 completed 后：
1. 通知所有 teammate 收工（`mailbox_send` 或 `SendMessage`）。
2. 综合结果，向用户汇报整体成果。
3. 清理团队：
```
team_delete({ team_name })
```
（team_delete 会拒绝删除还有成员的团队——先让 teammate 退出。）

## 2. 任务认领机制（理解 teammate 怎么并行）

teammate 用 `claim_task` 原子认领任务，**文件锁保证不会两个 teammate 拿到同一个任务**：
- 认领成功 → teammate 执行 → 标记 completed → 报告你
- 任务已被认领 → teammate 自动试下一个
- 任务被阻塞（依赖未完成）→ teammate 先做别的
- 无可认领任务 → teammate 报告 idle

所以你**不需要手动分配**——把任务放进列表，teammate 自己竞争认领。你只需关注：任务够不够分、idle 的 teammate 要不要续传、有没有新任务要加。

## 3. teammate 间协作

teammate 之间通过 mailbox 直接通信（绕过 ZCode 的星型限制）：
- teammate A 发现要 B 配合：`mailbox_send({ to: "worker-B", ... })`
- teammate 发现新工作：`task_create` 加进列表，任何空闲 teammate 都能认领
- 你要看全队状态：`team_info({ team_name })`

## 4. 何时用 Swarm vs Coordinator

| 场景 | 推荐 |
|------|------|
| 并行修复 10 个独立的 lint 警告 | Swarm（任务独立，teammate 各领各的）|
| 在大仓库搜索所有 TODO 并分类 | Swarm（无依赖，各自领任务）|
| 重构认证系统（多模块有依赖） | Coordinator（集中决策，Worker 间有依赖）|
| 研究方案 A 和 B 然后选一个实现 | Coordinator（先并行研究，再集中决策）|

**Swarm 适合**：任务可独立拆分、能并行、无强依赖。
**Coordinator 适合**：需要集中综合决策、任务间有顺序依赖。

## 5. 示例：并行修 3 个独立 bug

用户："/swarm 并行修这 3 个 bug：[bug1 in auth.ts], [bug2 in api.ts], [bug3 in db.ts]"

你：
  1. `team_create({ team_name: "bugfix-batch", description: "并行修3个独立bug" })`
  2. 三个 `task_create`，各描述一个 bug（独立，无 blocked_by）
  3. 一条消息里发三个 Agent：
     ```
     Agent({ subagent_type: "teammate", prompt: "team=bugfix-batch, name=worker-A, ..." })
     Agent({ subagent_type: "teammate", prompt: "team=bugfix-batch, name=worker-B, ..." })
     Agent({ subagent_type: "teammate", prompt: "team=bugfix-batch, name=worker-C, ..." })
     ```
  4. 告诉用户："已组建 3 人团队并行修复，启动 worker-A/B/C。"
  5. 等 teammate 报告 → `mailbox_read` 收结果 → 综合
  6. 全部完成 → `team_delete` → 向用户汇报：3 个 bug 都修了，改动如下...

## 6. 关键约束

- **teammate 看不到你的对话**：任务 description 必须自包含，写清文件路径/行号/要做什么。
- **不要用终端工具看团队活动**：用 `mailbox_read` / `task_list` / `team_info`，不要 `Bash` 翻日志。
- **身份用 name 不用 id**：mailbox_send 的 `to` 和 task 的 `owner` 都用 teammate 的显示名（worker-A），不是 agent id。
- **idle 是正常的**：teammate 完成一轮报告 idle 不代表出错——它只是在等新任务。有任务就续传，没任务就收工。
- **工具结果会偶发重复**（调用方行为，非插件 bug）：单次 `task_create` 可能产出两个相同任务，单次 `mailbox_send` 可能投递两份相同消息。插件 MCP server 本身正确（已隔离验证），重复来自底层模型生成重复 tool_use 或 ZCode 重试。因此两个固定动作不可省：①建完任务后 `task_list` 核对，用 `task_update(status:"completed")` 收掉重复任务；②读邮箱后按内容去重，相同的报告视为一条。不做这两步，重复任务会被 teammate 重复执行、重复报告会干扰你的综合判断。
