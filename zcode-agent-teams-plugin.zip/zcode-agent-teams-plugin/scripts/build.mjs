import { build } from 'esbuild'

// Output CommonJS to a .cjs file. Two reasons:
//  1. proper-lockfile / graceful-ffs are CJS that call require() internally
//     (require('path'), etc.). Bundling them into an ESM output breaks those
//     dynamic requires ("Dynamic require of X is not supported"). CJS keeps
//     require() working.
//  2. package.json has "type":"module", so Node treats *.js as ESM. A CJS
//     bundle must therefore use the .cjs extension, or module.exports throws.
// The MCP server talks over stdio, so the module format is invisible to
// callers — .cjs is safe here.
await build({
  entryPoints: ['src/server.ts'],
  outfile: 'dist/server.cjs',
  bundle: true,
  platform: 'node',
  target: 'node20',
  format: 'cjs',
  sourcemap: false,
  minify: false,
  logLevel: 'info',
  banner: { js: '#!/usr/bin/env node' },
  packages: 'bundle',
})

console.log('Build complete: dist/server.cjs')
