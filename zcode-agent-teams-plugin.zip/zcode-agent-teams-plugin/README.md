# ZCode Agent Teams 插件

为 ZCode 桌面版提供两种多 Agent 编排模式，把复杂任务拆分给多个子 agent 并行执行。

- `/coordinator <任务>` — 星型编排：主 agent 当协调者，派发 worker 子 agent 并行研究/实现/验证，综合结果回报用户。
- `/swarm <任务批次>` — 蜂群协作：组建团队，共享任务列表 + 文件邮箱，teammate 竞争认领并行执行。

## 两种模式对比

| 维度 | Coordinator | Swarm |
|------|-------------|-------|
| **拓扑** | 星型：coordinator 居中，worker 外围 | 星型 + P2P：lead 协调，teammate 间可经 mailbox 直连 |
| **任务分配** | coordinator 综合后主动派发 | teammate 从共享列表竞争认领（文件锁原子） |
| **通信** | ZCode 内置 SendMessage（lead→worker 续传） | 文件邮箱（任意 teammate 间）+ 共享任务列表 |
| **协调者工具** | Agent、SendMessage（纯 ZCode 内置，无 MCP 工具） | team/mailbox/task 三类 MCP 工具 |
| **子 agent 类型** | worker（全套标准工具） | teammate（标准工具 + 全部 swarm MCP 工具） |
| **适用** | 需要集中综合决策、任务有顺序依赖 | 任务可独立拆分、能完全并行 |

## 数据模型（ER 图）

下面用 ER 图描述插件的核心数据结构及其关系。所有字段来自真实代码（`src/lib/teamFile.ts` 的 `TeamFile`/`TeamMember`、`src/lib/taskList.ts` 的 `Task`/`ClaimResult`、`src/lib/mailbox.ts` 的 `TeammateMessage`）。

```
┌─────────────────────────────────────────────────────────────────────┐
│                        TeamFile (团队配置)                           │
│            位置: ~/.zcode/teams/{team-name}/config.json              │
│            定义: src/lib/teamFile.ts                                 │
├─────────────────────────────────────────────────────────────────────┤
│  name         : string        ← 团队名（主键）                       │
│  description? : string        ← 团队目标                             │
│  createdAt    : number        ← 创建时间（epoch ms）                  │
│  leadAgentId  : string        ← 负责人 id "team-lead@{team}"         │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ 1
                               │
                               │ N
┌──────────────────────────────▼──────────────────────────────────────┐
│                          TeamMember (成员)                           │
│            定义: src/lib/teamFile.ts                                 │
├─────────────────────────────────────────────────────────────────────┤
│  agentId    : string        ← "name@team"（主键，邮箱寻址用）        │
│  name       : string        ← 显示名（mailbox to / task owner 用）   │
│  agentType? : string        ← 角色（teammate / 自定义）              │
│  model?     : string        ← 模型                                   │
│  taskId?    : string        ← ZCode 子 agent task id（SendMessage 用）│
│  isActive?  : boolean       ← true=活跃 / false=idle                │
│  joinedAt   : number        ← 加入时间                               │
│  subscriptions: string[]    ← 订阅                                   │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ 一个成员拥有
                               │
                               ▼
              ┌────────────────────────────────┐
              │   成员状态机 (isActive 字段)     │
              ├────────────────────────────────┤
              │  spawn → isActive:true (活跃)   │
              │  完成一轮 → isActive:false(idle)│
              │  lead 续传 → 唤醒 → true        │
              └────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────┐
│                            Task (任务)                                │
│            位置: ~/.zcode/tasks/{team-name}/{id}.json                │
│            定义: src/lib/taskList.ts                                 │
├─────────────────────────────────────────────────────────────────────┤
│  id          : number        ← 递增整数（主键，不因 reset 复用）      │
│  subject     : string        ← 任务标题                               │
│  description?: string        ← 工作说明（自包含，teammate 据此执行）   │
│  owner?      : string        ← 认领者 name（claim_task 设置）         │
│  status      : TaskStatus    ← pending | in_progress | completed     │
│  blocks      : number[]      ← 本任务阻塞了哪些任务 id（反向依赖）    │
│  blockedBy   : number[]      ← 本任务被哪些任务 id 阻塞（正向依赖）   │
│  metadata?   : Record        ← 任意扩展数据                           │
└──────────────────────────────┬──────────────────────────────────────┘
                               │ status / owner 取值由下方状态机决定
                               │
                ┌──────────────▼──────────────────┐
                │      Task 状态机 (status)        │
                │      定义: taskList.ts           │
                ├──────────────────────────────────┤
                │  pending    → 未认领，可被认领    │
                │  in_progress → 已认领，执行中     │
                │  completed  → 已完成，不可再认领  │
                └──────────────┬──────────────────┘
                               │ 认领原子性由 claim_task 保证
                               ▼
              ┌─────────────────────────────────────────┐
              │         ClaimResult (认领结果)           │
              │         定义: taskList.ts                │
              ├─────────────────────────────────────────┤
              │  claimed         → 认领成功，owner 已设  │
              │  already_claimed → 已被别人认领          │
              │  already_resolved→ 任务已完成            │
              │  blocked         → 依赖任务未完成        │
              │  agent_busy      → 已持有 in_progress 任务│
              │  task_not_found  → 任务不存在            │
              └─────────────────────────────────────────┘
  注: blockedBy 中的任务只要有一个 status≠completed，
      本任务就处于 blocked，无法被认领。
      认领用 proper-lockfile 文件锁保证原子性，并发 teammate 不会抢到同一个。


┌─────────────────────────────────────────────────────────────────────┐
│                     TeammateMessage (邮箱消息)                       │
│            位置: ~/.zcode/teams/{team}/inboxes/{agent}.json          │
│            定义: src/lib/mailbox.ts                                  │
├─────────────────────────────────────────────────────────────────────┤
│  from      : string        ← 发送者 name                             │
│  text      : string        ← 消息正文（≤ 64KB）                      │
│  timestamp : string        ← ISO 时间戳                              │
│  read      : boolean       ← 是否已读                                 │
│  color?    : string        ← 发送者颜色                               │
│  summary?  : string        ← 5-10 词预览                              │
└─────────────────────────────────────────────────────────────────────┘
  邮箱是 JSON 数组，写入用 per-inbox 文件锁（proper-lockfile）串行化，
  并发 teammate 写同一收件人不会互相覆盖。自动压缩：保留近期未读 +
  限量已读，单文件上限 4MB。
```

### 核心数据流

```
【Coordinator 模式】
用户: /coordinator <任务>
   │
   ▼
command 注入编排 system prompt + 激活 coordinator skill
   │
   ▼
主 agent 进入 coordinator 角色
   │
   ├──► Research: 并行 Agent(subagent_type:"worker", prompt:研究任务×N)
   │        worker 独立子进程执行，完成返回结果
   │
   ├──► Synthesis: coordinator 自己理解发现（禁止懒惰委派）
   │
   ├──► Implementation: Agent(subagent_type:"worker", prompt:精确实现规格)
   │        失败 → SendMessage(to:agent_id, message:修正) 续传同一 worker
   │
   └──► Verification: Agent(subagent_type:"worker", prompt:独立验证)
            证明代码能用，不盖章


【Swarm 模式】
用户: /swarm <任务批次>
   │
   ▼
command 注入 team-lead system prompt + 激活 swarm skill
   │
   ▼
主 agent 作为 lead:
   │
   ├──► team_create(team_name) ──► [TeamFile] + 共享 task list 目录
   │
   ├──► task_create × N ───────► [Task: pending]
   │
   ├──► 并行 Agent(subagent_type:"teammate", prompt:含身份)
   │        每个 teammate 独立子进程:
   │          team_join → mailbox_read → task_list → claim_task(文件锁)
   │            │
   │            ├── claimed → 执行 → task_update(completed)
   │            │            → mailbox_send(to:team-lead, 报告)
   │            │            → 继续 task_list 认领下一个（循环）
   │            │
   │            └── 无可认领 → mailbox_send(idle 报告) → 退出
   │
   ├──► lead 轮询 mailbox_read(team-lead) 收报告
   │        有未完成任务 + idle teammate
   │          → SendMessage(to:agent_id, 续传新任务) 唤醒
   │
   └──► 全部 completed → team_delete 清理 → 向用户汇报
```

## 安装

### 前置
- macOS（ZCode 桌面版）
- Node.js ≥ 20
- ZCode 桌面版（v3.2.0+）

### 步骤
```bash
# 把插件目录放到任意位置，例如 ~/zcode-agent-teams-plugin
cd <插件目录>
npm install
npm run build   # 产出 dist/server.cjs
```

注册到 ZCode：在 `~/.zcode/cli/config.json` 的 `plugins.dirs` 加入插件目录的**绝对路径**：
```json
{
  "plugins": {
    "dirs": ["<插件目录的绝对路径>"]
  }
}
```
> plugin.json 里 MCP server 的启动路径用的是 `${ZCODE_PLUGIN_ROOT}/dist/server.cjs` 变量，ZCode 会自动替换成插件实际根路径，所以插件放在哪个目录都行，无需改 plugin.json。

重启 ZCode 桌面端，`/plugins` 应看到 `zcode-agent-teams` 启用。

## 使用

### Coordinator 模式
```
/coordinator 重构认证系统，需要多模块协调
```
主 agent 进入编排角色，用 `Agent(subagent_type:"worker")` 并行派发研究，综合后派发实现，失败用 `SendMessage` 续传 worker 修正。

### Swarm 模式
```
/swarm 并行修复这 10 个独立的 lint 警告
```
主 agent 作为 team lead：`team_create` → `task_create` 拆任务 → 并行 `Agent(subagent_type:"teammate")` 派发 → teammate 自主循环认领执行 → `mailbox_read` 收报告 → 全完成 `team_delete` 收工。

## 架构

```
zcode-agent-teams-plugin/
├── .zcode-plugin/plugin.json     # 清单：MCP server + skills + commands + agents
├── commands/                     # /coordinator、/swarm 命令（注入 system prompt）
├── skills/                       # coordinator、swarm 编排指南
├── agents/                       # worker.md、teammate.md（静态 agent profile）
├── src/
│   ├── server.ts                 # MCP server（StdioServerTransport）
│   ├── tools/                    # 16 个 swarm 工具（team/mailbox/task）
│   └── lib/                      # 文件系统层（mailbox/teamFile/taskList/lockfile）
└── dist/server.cjs               # 构建产物（proper-lockfile 已打包）
```

### MCP 工具（swarm 专用，16 个）

| 类别 | 工具 |
|---|---|
| **团队** | `team_create`, `team_delete`, `team_info`, `team_join`, `team_set_active` |
| **邮箱** | `mailbox_send`, `mailbox_broadcast`, `mailbox_read`, `mailbox_read_all`, `mailbox_clear` |
| **任务** | `task_create`, `task_list`, `task_info`, `task_update`, `claim_task`, `task_reset` |

> `/coordinator` 不用 MCP 工具——它纯靠 ZCode 内置的 Agent + SendMessage。

### 数据存储
```
~/.zcode/teams/{team-name}/
├── config.json               # 团队配置 + 成员列表
└── inboxes/{agent-name}.json # 每个 teammate 的文件邮箱（JSON 消息数组）
~/.zcode/tasks/{team-name}/
├── 1.json, 2.json ...        # 每个任务一个文件
├── .lock                     # 列表级锁（busy-check 用）
└── .highwatermark            # 最大已分配 id（防 reset 后复用）
```

## 关键设计决策

1. **身份显式传入**：ZCode 子 agent 是隔离进程，无共享上下文。teammate 的身份（`team_name`/`agent_name`）由 lead 在 spawn 时写进 prompt，所有 MCP 工具调用显式传这两个参数。
2. **mailbox 续传式**：ZCode 子 agent 跑完即退出（无持久 idle 循环）。Swarm 靠文件邮箱——teammate 完成报告 idle，lead 用 `SendMessage` 续传新任务唤醒它。
3. **邮箱绕过星型限制**：ZCode 内置 SendMessage 只能 lead→child；teammate 间用文件邮箱实现任意两点直接通信。
4. **文件锁原子认领**：`claim_task` 用 proper-lockfile 锁单个任务文件，保证并发 teammate 不会抢到同一个任务。
5. **teammate 工具白名单**：teammate 的 `tools` 字段显式列出全部 MCP 工具名（`mcp__swarm__*`），否则 ZCode 运行时按白名单过滤会漏掉 MCP 工具。
6. **CJS 输出**：proper-lockfile 是 CJS 模块，打包成 ESM 会破坏其内部 `require()`；输出 `.cjs` 规避。

## 开发
```bash
npm run typecheck   # tsc --noEmit
npm run build       # esbuild → dist/server.cjs
```

## 已知限制
- teammate 无法持久后台 idle（ZCode 子进程一次性）——靠 mailbox 续传模拟，依赖 lead 主动调度。
- task 通知是轮询式（lead `mailbox_read` / `task_list`），非 push 推送。
- 无权限同步——v1 用默认权限模式。

## 已知现象：MCP 工具调用结果偶发重复（非插件 bug）

**现象**：lead 或 teammate 调用一次 `task_create` / `mailbox_send`，偶发产出两份结果——任务列表里出现两条内容完全相同的任务，或收件箱收到两条相同的消息。

**已排除插件侧原因**：隔离测试（单独用 stdio 跑 `dist/server.cjs`，手动发一次 `tools/call`）证明 MCP server 单次调用只产出 1 个任务 / 1 条消息。插件本身的 `createTask`、`writeToMailbox`、文件锁逻辑均正确，无重复写入。

**真实来源（调用方，非本插件）**：底层模型（如 GLM-5.2）在生成 tool_use 时偶发产生重复的 tool_use 块，或 ZCode 对 MCP 工具调用存在某种重试/双发机制——两种情况下工具实际被执行了两次，每次都正确落盘，故表现为"双份"。

**判断依据**：
- 隔离测试（纯 MCP server）：`task_create` 产 1 个、`mailbox_send` 投 1 条 ✅
- 实际 ZCode 运行：同一 turn 内 `tool.call.started` 事件间隔仅几毫秒连续触发多次（非模型主动串行调用应有的节奏）
- 任务文件的 mtime 不同（相差数十秒），说明是两次独立的工具调用，而非单次调用双写

**影响**：功能上无害（重复的任务可被 teammate 正常认领，重复的消息可被收件人正常读取），仅状态略冗余。

**缓解建议（lead 侧编排技巧）**：
- 建任务后用 `task_list` 核对，发现重复即用 `task_update(status:"completed")` 收掉多余的 pending 任务
- 收件人读邮箱后用 `mailbox_mark_read` / `mailbox_clear` 清理，避免重复消息堆积

> 此现象无法在插件侧修复（调用方行为），已记录在此供排查。
